// import axios from "axios";

// export function api() {
//   const getApi = async () => {
//     try {
      

//       await axios.put("https://6508523156db83a34d9c20cf.mockapi.io/api/chandru/" + 1, {
//             clicks :99
//         });

//     } catch (ex) {}
//   };
// }
