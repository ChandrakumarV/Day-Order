function Header() {
    return (
        <div className='header'>
            <h1>Government arts college karur</h1>
            <p>3<sup>rd</sup> B.Sc Computer Science (Shift-1)</p>
        </div>
    )
}

export default Header
